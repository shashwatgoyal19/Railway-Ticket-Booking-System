
Railway Ticket Booking System

Connector required-
mysql-jdbc Connector for java,
jar-file of jdbc calendar,
mysql workbench


To run the code-
railway_create.sql file is provided run it on workbench to create the database and then 
Simple after opening the project add mysql-jdbc connector to your project.
Also add jar file of jdbc-calendar into your file
then simply run the Railway_Reservation.java file
and the project would start running

First register a user.
Then userName to access functionalities of Admin are 123 
and the password is 123.

then you can access the functions of admin and user after proper Login.

